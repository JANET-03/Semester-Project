
#include <iostream>
#include <map>
#include <string>

using namespace std;

int main() {
    map<string, string> passwordDatabase;
    string username, password;
    int choice;

    do {
        cout << "1. Store password" << endl;
        cout << "2. Retrieve password" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter username: ";
                cin >> username;
                cout << "Enter password: ";
                cin >> password;
                passwordDatabase[username] = password;
                cout << "Password stored successfully!" << endl;
                break;
            case 2:
                cout << "Enter username: ";
                cin >> username;
                if (passwordDatabase.find(username) != passwordDatabase.end()) {
                    password = passwordDatabase[username];
                    cout << "Password for " << username << ": " << password << endl;
                } else {
                    cout << "Username not found!" << endl;
                }
                break;
            case 3:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
                break;
        }

        cout << endl;
    } while (choice != 3);

    return 0;
}
